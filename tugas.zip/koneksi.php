<?php
$servername = "localhost";
$username = "root"; // Ubah sesuai dengan konfigurasi MySQL Anda
$password = ""; // Ubah sesuai dengan konfigurasi MySQL Anda
$dbname = "db_abdulmalikfajar_ukk_rpl_2024";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
