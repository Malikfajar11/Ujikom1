<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'mahasiswa') {
    header("Location: login.php");
    exit();
}

$nim = $_SESSION['username'];

// Ambil data pengajuan berdasarkan NIM dari session
$sql = "SELECT * FROM pengajuan WHERE nim = (SELECT nim FROM mahasiswa WHERE username='$nim')";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Pengajuan Anda</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Status Pengajuan Anda</h2>
        <table>
            <tr>
                <th>ID Pengajuan</th>
                <th>Tanggal</th>
                <th>Topik Skripsi</th>
                <th>Status</th>
            </tr>
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id_pengajuan']; ?></td>
                    <td><?php echo $row['tgl_pengajuan']; ?></td>
                    <td><?php echo $row['isi_pengajuan']; ?></td>
                    <td>
                        <?php 
                        if ($row['status'] == '0') {
                            echo "Belum Ditanggapi";
                        } elseif ($row['status'] == 'proses') {
                            echo "Proses";
                        } elseif ($row['status'] == 'selesai') {
                            echo "Selesai";
                        }
                        ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">Belum ada pengajuan.</td>
                </tr>
            <?php endif; ?>
        </table>
        <a href="index.php" class="link">Kembali ke Dashboard</a>
    </div>
</body>
</html>
