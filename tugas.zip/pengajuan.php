<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'mahasiswa') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tgl_pengajuan = date("Y-m-d");
    $username = $_SESSION['username'];

    // Cari NIM berdasarkan username
    $result = $conn->query("SELECT nim FROM mahasiswa WHERE username='$username'");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nim = $row['nim'];
    } else {
        echo "NIM tidak ditemukan.";
        exit();
    }

    $isi_pengajuan = $_POST['isi_pengajuan'];
    $status = '0';

    $sql = "INSERT INTO pengajuan (tgl_pengajuan, nim, isi_pengajuan, status) 
            VALUES ('$tgl_pengajuan', '$nim', '$isi_pengajuan', '$status')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Pengajuan berhasil dikirim!');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengajuan Topik Skripsi</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Ajukan Topik Skripsi</h2>
        <form method="POST" action="">
            Topik Skripsi: <textarea name="isi_pengajuan" required></textarea><br>
            <input type="submit" value="Kirim" class="button">
        </form>
        <a href="index.php" class="link">Kembali ke Dashboard</a>
    </div>
</body>
</html>
