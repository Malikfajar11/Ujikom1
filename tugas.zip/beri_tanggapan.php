<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'prodi') {
    header("Location: login.php");
    exit();
}

$id_pengajuan = $_GET['id']; // Ambil ID pengajuan dari URL

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tanggapan = $_POST['tanggapan'];
    $tgl_tanggapan = date("Y-m-d");
    
    // Ambil id_prodi berdasarkan username dari session
    $username = $_SESSION['username'];
    $result = $conn->query("SELECT id_prodi FROM prodi WHERE username='$username'");
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id_prodi = $row['id_prodi'];
    } else {
        echo "ID Prodi tidak ditemukan.";
        exit();
    }

    $sql = "INSERT INTO tanggapan (id_pengajuan, tgl_tanggapan, tanggapan, id_prodi) 
            VALUES ('$id_pengajuan', '$tgl_tanggapan', '$tanggapan', '$id_prodi')";

    if ($conn->query($sql) === TRUE) {
        $update_status = "UPDATE pengajuan SET status='selesai' WHERE id_pengajuan='$id_pengajuan'";
        $conn->query($update_status);

        echo "<script>alert('Tanggapan berhasil diberikan!'); window.location.href='list_pengajuan.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beri Tanggapan</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Beri Tanggapan</h2>
        <form method="POST" action="">
            Tanggapan: <textarea name="tanggapan" required></textarea><br>
            <input type="submit" value="Tanggapi" class="button">
        </form>
        <a href="list_pengajuan.php" class="link">Kembali ke Daftar Pengajuan</a>
    </div>
</body>
</html>
