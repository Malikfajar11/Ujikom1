<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'prodi') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pengaduan = $_POST['id_pengaduan'];
    $tgl_tanggapan = date("Y-m-d");
    $tanggapan = $_POST['tanggapan'];
    $id_petugas = $_SESSION['username'];

    $sql = "INSERT INTO tanggapan (id_pengaduan, tgl_tanggapan, tanggapan, id_petugas) 
            VALUES ('$id_pengaduan', '$tgl_tanggapan', '$tanggapan', '$id_petugas')";
    if ($conn->query($sql) === TRUE) {
        // Update status pengaduan menjadi 'proses'
        $sql_update = "UPDATE pengaduan SET status='proses' WHERE id_pengaduan='$id_pengaduan'";
        if ($conn->query($sql_update) === TRUE) {
            echo "<script>showMessage('Tanggapan berhasil diberikan dan status pengaduan diperbarui!', 'success');</script>";
        } else {
            echo "<script>showMessage('Error dalam memperbarui status pengaduan: " . $sql_update . "', 'error');</script>";
        }
    } else {
        echo "<script>showMessage('Error: " . $sql . "', 'error');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beri Tanggapan</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/script.js" defer></script>
</head>
<body>
    <div class="container">
        <h2>Beri Tanggapan</h2>
        <form method="POST" action="">
            ID Pengajuan: <input type="text" name="id_pengaduan" required><br>
            Tanggapan: <textarea name="tanggapan" required></textarea><br>
            <input type="submit" value="Tanggapi" class="button">
        </form>
        <a href="index.php" class="link">Kembali ke Dashboard</a>
    </div>
</body>
</html>

   
