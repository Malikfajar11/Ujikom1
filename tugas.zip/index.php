<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pengajuan Skripsi</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Selamat datang, <?php echo $_SESSION['username']; ?>!</h2>

        <?php if ($role == 'mahasiswa'): ?>
            <a href="pengajuan.php" class="button">Ajukan Topik Skripsi</a>
            <a href="status_pengajuan.php" class="button">Lihat Status Pengajuan</a>
        <?php elseif ($role == 'prodi'): ?>
            <a href="list_pengajuan.php" class="button">Lihat Daftar Pengajuan</a>
        <?php endif; ?>

        <a href="logout.php" class="button logout">Logout</a>
    </div>
</body>
</html>
